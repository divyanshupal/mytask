<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Task</title>
</head>
<body>
    <h1>Add Task</h1>
    <?php
    $con=mysqli_connect('localhost','root','','task');
    $query="select * from user";
    $res=mysqli_query($con,$query);
    if(mysqli_num_rows($res)>0) 
    {
    ?>
    <form action="taskcode.php" method="post">
        <select name="name" id="">
            <option value="select">Select</option>
        <?php
        while($row=mysqli_fetch_assoc($res))
        {
        ?>
            <option value="<?php echo $row['name']; ?>"><?php echo $row['name']; ?></option>
            <?php
        }
        ?>
        </select>
        <br><br>
        Task Detail :
        <input type="text" name="taskdetail" id=""> <br> <br>
        Task Type :
        <input type="text" name="tasktype" id=""/> <br> <br>
        <input type="submit" name="submit" id=""/> <br> <br>

    <?php
    }
    ?>
    <br> <br>
    <button><a href="index.php">Back</a></button>

    </form>
</body>
</html>