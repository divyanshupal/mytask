<?php
if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $taskdetail=$_POST['taskdetail'];
    $tasktype=$_POST['tasktype'];
    $con=mysqli_connect('localhost','root','','task');
$query="insert into task(name,taskdetail,tasktype,status) values('$name','$taskdetail','$tasktype','Yes')";
$res=mysqli_query($con,$query);
if($res)
{
    echo "success";
}
else
{
    echo "faild".$con->error;
}
}

?>