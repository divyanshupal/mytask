<?php
$name=$_POST['name'];
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$con=mysqli_connect('localhost','root','','task');
$query1="select * from user where email='$email'";
$res=mysqli_query($con,$query1);
if($row=mysqli_fetch_assoc($res))
{
    echo "<script>alert('This email is already registered');window.location.href='index.php';</script>";
}
else
{
$query="insert into user(name,email,mobile) values('$name','$email','$mobile')";
mysqli_query($con,$query);
echo "Success";
}
?>