<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All user display</title>
</head>
<body>
    <h1>Show All user</h1>
    <?php
    $con=mysqli_connect('localhost','root','','task');
    $query="select * from task";
    $res=mysqli_query($con,$query);
    if(mysqli_num_rows($res)>0) 
    {
    ?>
    <table border="2">
         <tr>
            <th>Name</th>
            <th>taskdetail</th>
            <th>tasktype</th>
            <th>Status</th>

         </tr>
         <?php
        while($row=mysqli_fetch_assoc($res))
        {
        ?>
        <tr>
        <td><?php echo $row["name"] ?></td>
        <td><?php echo $row["taskdetail"] ?></td>
        <td><?php echo $row["tasktype"] ?></td>
        <td><?php echo $row["status"] ?></td>
        </tr>
        <?php
        }
        ?>
    </table>
    <?php
        }
        else
        {
            echo "No record Found";
        }
        
        ?>
         <br> <br>
        <button><a href="index.php">Back</a></button>
</body>
</html>