<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All user display</title>
</head>
<body>
    <h1>Show All user</h1>
    <?php
    $con=mysqli_connect('localhost','root','','task');
    $query="select * from user";
    $res=mysqli_query($con,$query);
    if(mysqli_num_rows($res)>0) 
    {
    ?>
    <table border="2">
         <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Mobile</th>
         </tr>
         <?php
        while($row=mysqli_fetch_assoc($res))
        {
        ?>
        <tr>
        <td><?php echo $row["id"] ?></td>
        <td><?php echo $row["name"] ?></td>
        <td><?php echo $row["email"] ?></td>
        <td><?php echo $row["mobile"] ?></td>
        </tr>
        <?php
        }
        ?>
    </table>
    <?php
        }
        else
        {
            echo "No record Found";
        }
        
        ?>
        <br><br>
        <button><a href="index.php">Back</a></button>
</body>
</html>